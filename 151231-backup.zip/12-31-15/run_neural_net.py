#!/usr/bin/python

from pyfann import libfann

ann = libfann.neural_net()
ann.create_from_file("leaf_sep5.net")
#0.1132897603,0.1568627451,0.1590413943,0.1154684096,0.0087145969
print ann.run([0.1132897603,0.1568627451,0.1590413943,0.1154684096,0.0087145969])